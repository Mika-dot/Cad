# AFVM Studio — Visual Studio research demonstrator

Это полноценный **Visual Studio / WinForms / OpenGL** проект для исследования адаптивного функционально-воксельного представления и R-функциональной алгебры.

Целевая среда: **.NET 10 / Windows x64**. Это выбрано специально под современную Visual Studio и не требует .NET 8 runtime, из-за которого падала предыдущая Debug-сборка.

## Запуск в Visual Studio

1. Открыть `AFVM_Studio.sln`.
2. Дождаться NuGet restore.
3. Убедиться, что стартовый проект — `AFVM.Studio`.
4. Нажать **F5**.

Зависимости восстанавливаются автоматически:
- OpenTK 4.9.4;
- OpenTK.GLControl 4.0.2.

## Что теперь есть в интерфейсе

### Представления
- Overview 2×2;
- Exact analytic;
- Uniform FV;
- Adaptive Direct;
- Adaptive R(Ah,Bh).

### Слои
- поверхность;
- границы FV-ячеек;
- локальные плоскости `L_i(x)=0`, геометрически обрезанные конкретным вокселем;
- локальные нормали;
- heatmap геометрической ошибки;
- wireframe.

Есть пресеты: `CAD`, `FV geometry`, `Error`, `Structure`.

### Сечения X/Y/Z
Для каждой оси:
- отдельное включение;
- TrackBar;
- численное положение плоскости;
- `keep <=` / `keep >=` — выбор сохраняемой стороны;
- одновременная работа нескольких осей;
- контур реального пересечения активного implicit/FV-поля с плоскостью;
- цветная рамка секущей плоскости.

Цвета:
- X — красный;
- Y — зелёный;
- Z — синий.

Срез применяется **одновременно к поверхности, FV-ячейкам, локальным плоскостям и нормалям** через OpenGL clipping uniforms. Контуры сечения считаются отдельно marching-squares непосредственно по выбранному представлению, поэтому можно сравнивать Exact / Uniform / Adaptive Direct / Adaptive R на одном и том же срезе.

### Камера
- ISO;
- Front;
- Right;
- Top;
- Fit/reset;
- ЛКМ — orbit;
- ПКМ — pan;
- wheel — zoom;
- double click — reset.

### Параметры эксперимента
Прямо из GUI можно менять:
- tolerance;
- adaptive max depth;
- uniform depth;
- surface mesh resolution;

и нажимать `Rebuild experiment`. Вычисления идут в background task, после чего OpenGL-ресурсы пере загружаются на UI thread.

### Численные результаты
В правой панели таблица:
- число cells/leaves;
- RMS геометрической ошибки;
- max error;
- средняя ошибка нормали.

Ниже — подробности текущего представления.

## Горячие клавиши
- `F1` — overview;
- `1..4` — Exact / Uniform / Adaptive Direct / Adaptive R;
- `G` — cells;
- `P` — local planes;
- `N` — normals;
- `H` — error heatmap;
- `W` — wireframe;
- `Space` — surface on/off;
- `F` — reset camera.

## Проверки

В solution есть отдельный `AFVM.Studio.Tests`.

Проверяются:
1. `Restrict(Prolong(L)) = L` для аффинной локальной функции;
2. знаки R-difference;
3. пересечение плоскости `x=0` с кубом даёт корректный четырёхугольник;
4. X/Y/Z cross-section линии действительно лежат в заданной секущей плоскости;
5. default Adaptive-R использует меньше leaf, чем uniform baseline, и остаётся в заданных численных пределах ошибки.

Командно:
```powershell
dotnet restore AFVM_Studio.sln
dotnet build AFVM_Studio.sln -c Release
dotnet test AFVM_Studio.sln -c Release --no-build
```

## Научный смысл срезов

Секция теперь позволяет смотреть не только итоговую mesh-поверхность. Например:

1. выбрать `Adaptive R(Ah,Bh)`;
2. включить `FV geometry`;
3. включить X-cut;
4. убрать `Surface`;
5. двигать X slider.

Внутри объекта видны реальные размеры адаптивных leaf, локальные плоские элементы и их изменение по мере прохода сечения через область. Это непосредственно показывает неоднородное дискретно-непрерывное представление, а не только его внешнюю изоповерхность.
