# Architecture

`AFVM.Studio` разделён логически на два слоя.

## Core
`Core/` не зависит от OpenGL:
- implicit/R fields;
- local linear functions;
- uniform FV;
- adaptive FV tree;
- error estimator;
- surface extraction;
- local-plane/voxel clipping;
- cross-section marching squares;
- experiment builder and metrics.

## Rendering/UI
`Rendering/` и `MainForm*`:
- OpenTK 4.9.4 + OpenTK.GLControl 4.0.2;
- WinForms control panel;
- synchronized 2x2 overview;
- GPU clipping by X/Y/Z planes;
- section contours generated from the actual selected field;
- camera/orbit/pan/zoom;
- layer switching.

Scientific calculations do not depend on the UI. This keeps future work on prolongation/restriction/common-refinement testable without OpenGL.
