using AFVM.Studio.Core;
using Xunit;

namespace AFVM.Studio.Tests;

public class CoreTests
{
    [Fact]
    public void AffineProlongRestrictIsExact()
    {
        var f=new AffineField(1.25,new(2,-3,.5));
        var box=new Box3d(new(-1,-1,-1),new(1,1,1));
        var parent=new LocalLinearFunction(DVec3.Zero,f.Value(DVec3.Zero),f.Gradient(DVec3.Zero));
        var children=Enumerable.Range(0,8).Select(i=>parent.Prolong(box.Child(i).Center)).ToArray();
        var q=LocalLinearFunction.Restrict(children,DVec3.Zero);
        Assert.True(box.ProbePoints().Max(p=>Math.Abs(q.Value(p)-f.Value(p)))<1e-12);
        Assert.True((q.Gradient-f.Gradient(DVec3.Zero)).Length<1e-12);
    }

    [Fact]
    public void RDifferenceHasExpectedSigns()
    {
        Assert.True(RFunctions.Evaluate(-1,1,ROperation.Difference).value<0);
        Assert.True(RFunctions.Evaluate(-1,-1,ROperation.Difference).value>0);
    }

    [Fact]
    public void PlaneClipOfCubeProducesSquare()
    {
        var b=new Box3d(new(-1,-1,-1),new(1,1,1));
        var l=new LocalLinearFunction(DVec3.Zero,0,DVec3.UnitX);
        Assert.True(FunctionalVisualizationBuilder.TryPlanePolygon(b,l,out var poly));
        Assert.Equal(4,poly.Count);
        Assert.All(poly,p=>Assert.True(Math.Abs(p.X)<1e-10));
    }

    [Theory]
    [InlineData(SectionAxis.X)]
    [InlineData(SectionAxis.Y)]
    [InlineData(SectionAxis.Z)]
    public void CrossSectionLivesOnRequestedPlane(SectionAxis axis)
    {
        IField3d sphere=new SphereField(DVec3.Zero,1.0);
        var d=new Box3d(new(-1.5,-1.5,-1.5),new(1.5,1.5,1.5));
        var lines=CrossSectionBuilder.Build(sphere,d,axis,0.25,80);
        Assert.NotEmpty(lines);
        for(int i=0;i<lines.Length;i+=4)
        {
            double c=axis switch{SectionAxis.X=>lines[i],SectionAxis.Y=>lines[i+1],_=>lines[i+2]};
            Assert.InRange(c,0.249999,0.250001);
        }
    }

    [Fact]
    public void DefaultExperimentMeetsProofOfConceptBounds()
    {
        var e=ExperimentBuilder.Build(new ExperimentOptions(.025,6,5,36,64));
        var u=e[RepresentationKind.Uniform]; var r=e[RepresentationKind.AdaptiveR];
        Assert.True(r.CellCount<u.CellCount);
        Assert.True(r.Metrics.RmsDistance<0.01,$"RMS={r.Metrics.RmsDistance}");
        Assert.True(r.Metrics.MaxDistance<0.03,$"Max={r.Metrics.MaxDistance}");
        Assert.True(e.AdaptiveRReductionPercent>20);
    }
}
